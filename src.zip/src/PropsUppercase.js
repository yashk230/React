import React from "react";

export const PropsUppercase=(props)=>{
    return(<h1>Hii,{props.name.toUpperCase()}</h1>)
}

export default PropsUppercase;