import React from "react";

export const Props=(props)=>{
    return(<h1>Hii,{props.name}</h1>)
}

export default Props;