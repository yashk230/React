import React from "react";

export const CountProps=(props)=>{
    return(
    <h1>{props.count}</h1>
)
}

export default CountProps;